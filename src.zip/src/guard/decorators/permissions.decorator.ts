import { SetMetadata } from '@nestjs/common';
import { Permission } from '../constants/Permissions';

export const Permissions = (...permissions: Permission[]) => SetMetadata('permissions', permissions);
