import { HttpService } from '@nestjs/axios';
import { Body, Injectable } from '@nestjs/common';
import { Base64DocumentDto } from './dto/base64-document.dto';

@Injectable()
export class Base64DocumentService {

}
