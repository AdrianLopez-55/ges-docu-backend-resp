export class CreateOrganizationChartDto {}
