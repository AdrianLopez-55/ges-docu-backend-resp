export enum Permission {
  OBTENER_DOCUMENTOS = 'OBTENER_DOCUMENTOS',
  ADMIN = 'admin',
  SUPERADMIN = 'superadmin',
}

