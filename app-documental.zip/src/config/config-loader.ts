export const configLoader = () => {
	return {
		apiKey: process.env.API_KEY,
	};
};