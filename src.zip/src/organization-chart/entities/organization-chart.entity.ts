export class OrganizationChart {}
